package com.gl.docportaldrivergateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocportaldriverGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
